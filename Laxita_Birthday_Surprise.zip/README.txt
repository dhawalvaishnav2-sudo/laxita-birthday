LAXITA'S BIRTHDAY SURPRISE

This is a self-contained birthday page. It does not include or upload any photos.

HOW TO OPEN:
1. Extract the ZIP file.
2. Open index.html in Chrome on a phone or computer.

HOW TO MAKE A QR CODE:
A QR code must point to a link that your sister can open. The included QR code is only a placeholder until you publish/host the page.
For a free shareable page, you can use GitHub Pages (requires a free GitHub account) or another static website host. Upload index.html, publish the site, then create a QR code from the published https:// link.
Never enter passwords or private information into a QR-code site. The page itself contains no photos and does not collect data.
